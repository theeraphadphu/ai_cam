import os
import time
import base64
import json
import sys
from datetime import datetime
from pathlib import Path

import cv2
import requests
from ultralytics import YOLO

# --- อ่านค่าลับจาก environment variable ก่อน (Node-RED จะฉีดค่าเข้ามาให้ตอนสั่งรันผ่าน exec node) ---
CHANNEL_ACCESS_TOKEN = os.environ.get("LINE_CHANNEL_ACCESS_TOKEN", "")
USER_ID = os.environ.get("LINE_USER_ID", "")
IMGBB_API_KEY = os.environ.get("IMGBB_API_KEY", "")

# ถ้าไม่มี environment variable (เช่น รันสคริปต์นี้ตรง ๆ เองโดยไม่ผ่าน Node-RED)
# ให้ลองอ่านจากไฟล์ keys.json แทน เป็น fallback สำหรับทดสอบบนเครื่อง
if not CHANNEL_ACCESS_TOKEN or not USER_ID:
    KEYS_JSON_PATH = Path(
        os.environ.get("KEYS_JSON_PATH", "/home/pi/node-red-keys/keys.json")
    )
    if KEYS_JSON_PATH.exists():
        try:
            with open(KEYS_JSON_PATH, encoding="utf-8") as f:
                _creds = json.load(f)
            CHANNEL_ACCESS_TOKEN = CHANNEL_ACCESS_TOKEN or _creds.get("LINE_CHANNEL_ACCESS_TOKEN", "")
            USER_ID = USER_ID or _creds.get("LINE_USER_ID", "")
            IMGBB_API_KEY = IMGBB_API_KEY or _creds.get("IMGBB_API_KEY", "")
            print(f"[keys] โหลดค่าจาก {KEYS_JSON_PATH} (ไม่พบ environment variable)")
        except Exception as e:
            print(f"[keys] อ่านไฟล์ {KEYS_JSON_PATH} ไม่สำเร็จ: {e}", file=sys.stderr)

_missing = [
    name for name, val in [
        ("LINE_CHANNEL_ACCESS_TOKEN", CHANNEL_ACCESS_TOKEN),
        ("LINE_USER_ID", USER_ID),
    ] if not val
]
if _missing:
    print(
        "[ตั้งค่าไม่ครบ] ไม่พบค่าตัวแปรแวดล้อม: " + ", ".join(_missing) +
        "\nกรุณาสร้างไฟล์ .env (ดูตัวอย่างใน .env.example) หรือตั้งค่า environment variable ก่อนรัน",
        file=sys.stderr,
    )
    sys.exit(1)

MODEL_PATH = "yolo26n.pt"
CONFIDENCE_THRESHOLD = 0.5

CLASS_LABELS_TH = {
    "person": "มีคนเข้ามาในพื้นที่",
    "cat": "พบแมว",
    "dog": "พบสุนัข",
    "backpack": "พบพัสดุ/กระเป๋าวางอยู่",
    "suitcase": "พบพัสดุ/กระเป๋าเดินทางวางอยู่",
    "handbag": "พบพัสดุ/กระเป๋าวางอยู่",
}
TARGET_CLASSES = set(CLASS_LABELS_TH.keys())

COOLDOWN_SECONDS = 60
SNAPSHOT_DIR = Path("snapshots")
SNAPSHOT_DIR.mkdir(exist_ok=True)

WEBCAM_INDEX = 0  # ถ้ามีกล้องหลายตัว ลองเปลี่ยนเป็น 1, 2, ...

# --- Node-RED integration ---
# สคริปต์นี้จะถูกสั่งรันโดย Node-RED ผ่าน "exec" node (โหมด spawn/long-running process)
# Node-RED จะอ่าน stdout ของโปรเซสนี้แบบ real-time
# ทุกครั้งที่มีการแจ้งเตือน จะพิมพ์บรรทัด JSON ที่ขึ้นต้นด้วย EVENT_PREFIX ออกทาง stdout
# ให้ Node-RED (function node) แยกและ parse ต่อ
EVENT_PREFIX = "NODERED_EVENT:"

# รันผ่าน Node-RED exec node มักไม่มีจอ/หน้าต่างให้แสดงผล (headless)
# ถ้าต้องการเปิดหน้าต่างวิดีโอเพื่อดีบักบนเครื่อง ให้ตั้งเป็น False
HEADLESS = True


def emit_event(event: dict) -> None:
    """พิมพ์ event เป็น JSON บรรทัดเดียวออกทาง stdout ให้ Node-RED อ่านได้ทันที"""
    print(f"{EVENT_PREFIX}{json.dumps(event, ensure_ascii=False)}", flush=True)

def upload_image_to_imgbb(path: str) -> str | None:
    if not IMGBB_API_KEY:
        return None
    try:
        with open(path, "rb") as f:
            img_b64 = base64.b64encode(f.read()).decode("utf-8")
        resp = requests.post(
            "https://api.imgbb.com/1/upload",
            data={"key": IMGBB_API_KEY, "image": img_b64},
            timeout=15,
        )
        resp.raise_for_status()
        return resp.json()["data"]["url"]
    except Exception as e:
        print(f"[imgbb] อัปโหลดรูปไม่สำเร็จ: {e}")
        return None


def send_line_message(text: str, image_url: str | None = None) -> None:
    headers = {
        "Authorization": f"Bearer {CHANNEL_ACCESS_TOKEN}",
        "Content-Type": "application/json",
    }
    messages = [{"type": "text", "text": text}]
    if image_url:
        messages.append(
            {"type": "image", "originalContentUrl": image_url, "previewImageUrl": image_url}
        )
    payload = {"to": USER_ID, "messages": messages}

    try:
        resp = requests.post(
            "https://api.line.me/v2/bot/message/push",
            headers=headers,
            json=payload,
            timeout=10,
        )
        if resp.status_code != 200:
            print(f"[LINE] ส่งแจ้งเตือนไม่สำเร็จ: {resp.status_code} {resp.text}")
        else:
            print("[LINE] ส่งแจ้งเตือนสำเร็จ")
    except Exception as e:
        print(f"[LINE] เกิดข้อผิดพลาด: {e}")

def main():
    print("กำลังโหลดโมเดล YOLO ...")
    model = YOLO(MODEL_PATH)

    print("กำลังเปิดเว็บแคม ...")
    cap = cv2.VideoCapture(WEBCAM_INDEX)
    if not cap.isOpened():
        print(" เปิดเว็บแคมไม่ได้ ลองเปลี่ยนค่า WEBCAM_INDEX เป็น 1 หรือ 2")
        emit_event({"type": "error", "message": "webcam_open_failed"})
        return

    last_alert_time: dict[str, float] = {}
    print("เริ่มตรวจจับ... กด 'q' ในหน้าต่างวิดีโอ หรือ Ctrl+C เพื่อหยุด")
    emit_event({"type": "status", "message": "started"})

    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                print("อ่านภาพจากกล้องไม่ได้")
                break

            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = model(frame_rgb, verbose=False)

            detected_this_frame = set()

            for r in results:
                for box in r.boxes:
                    name = model.names[int(box.cls)]
                    conf = float(box.conf)

                    x1, y1, x2, y2 = map(int, box.xyxy[0])
                    color = (0, 255, 0) if name in TARGET_CLASSES else (150, 150, 150)
                    cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
                    cv2.putText(
                        frame, f"{name} {conf:.2f}", (x1, y1 - 8),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2,
                    )

                    if name in TARGET_CLASSES and conf >= CONFIDENCE_THRESHOLD:
                        detected_this_frame.add(name)

            if not HEADLESS:
                cv2.imshow(" Test - Object Detector", frame)

            now = time.time()
            for name in detected_this_frame:
                last = last_alert_time.get(name, 0)
                if now - last < COOLDOWN_SECONDS:
                    continue

                last_alert_time[name] = now
                timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                path = SNAPSHOT_DIR / f"{name}_{int(now)}.jpg"
                cv2.imwrite(str(path), frame)

                text = f" {CLASS_LABELS_TH[name]}\nเวลา: {timestamp}\n"

                url = upload_image_to_imgbb(str(path))
                send_line_message(text, url)
                print(f"[แจ้งเตือน] {text}")

                emit_event({
                    "type": "detection",
                    "class": name,
                    "label_th": CLASS_LABELS_TH[name],
                    "time": timestamp,
                    "snapshot_path": str(path),
                    "image_url": url,
                })

            if not HEADLESS:
                if cv2.waitKey(1) & 0xFF == ord("q"):
                    break

    except KeyboardInterrupt:
        print("\nหยุดการทำงาน")
    finally:
        cap.release()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()